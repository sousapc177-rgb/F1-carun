package com.mission.openworld

import android.opengl.GLES30

object Shaders {

    private val SKY_FN = """
vec3 skyColor(vec3 d) {
    vec3 horizon = vec3(0.74, 0.84, 0.95);
    vec3 zenith = vec3(0.18, 0.40, 0.82);
    float t = clamp(d.y, 0.0, 1.0);
    vec3 up = mix(horizon, zenith, pow(t, 0.5));
    vec3 down = mix(horizon * 0.85, vec3(0.28, 0.30, 0.27), clamp(-d.y * 4.0, 0.0, 1.0));
    return d.y >= 0.0 ? up : down;
}
float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
"""

    val MAIN_VS = """
#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNrm;
layout(location = 2) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
uniform vec4 uDmg;
uniform float uDeform;
out vec3 vWorld;
out vec3 vNrm;
out vec2 vUV;
out float vDmg;
void main() {
    vec3 p = aPos;
    float dm = 0.0;
    if (uDeform > 0.5) {
        float n = 0.5 + 0.5 * sin(p.x * 9.0 + p.y * 7.0) * sin(p.z * 8.0 + p.y * 5.0);
        float zf = smoothstep(0.8, 2.4, p.z);
        float zr = smoothstep(0.8, 2.4, -p.z);
        float xl = smoothstep(0.3, 1.0, p.x);
        float xr = smoothstep(0.3, 1.0, -p.x);
        p.z -= uDmg.x * zf * (0.25 + 0.45 * n);
        p.z += uDmg.y * zr * (0.25 + 0.45 * n);
        p.x -= uDmg.z * xl * (0.12 + 0.25 * n);
        p.x += uDmg.w * xr * (0.12 + 0.25 * n);
        float tot = uDmg.x * zf + uDmg.y * zr + uDmg.z * xl + uDmg.w * xr;
        p.y -= tot * 0.06 * n;
        dm = tot * n;
    }
    vec4 w = uModel * vec4(p, 1.0);
    vWorld = w.xyz;
    vNrm = mat3(uModel) * aNrm;
    vUV = aUV;
    vDmg = dm;
    gl_Position = uVP * w;
}
"""

    val MAIN_FS = """
#version 300 es
precision highp float;
in vec3 vWorld;
in vec3 vNrm;
in vec2 vUV;
in float vDmg;
uniform vec3 uCam;
uniform vec3 uSun;
uniform vec4 uColor;
uniform float uMetal;
uniform float uRough;
uniform int uMode;
uniform int uKind;
uniform int uUseTex;
uniform float uEmit;
uniform sampler2D uTex;
out vec4 fragColor;
""" + SKY_FN + """
void main() {
    vec3 fogCol = vec3(0.74, 0.84, 0.95);
    float dist = length(uCam - vWorld);
    float fog = clamp((dist - 220.0) / 520.0, 0.0, 1.0);

    if (uMode == 3) {
        vec2 p = vUV * 2.0 - 1.0;
        float a = clamp(1.0 - dot(p, p), 0.0, 1.0);
        fragColor = vec4(0.0, 0.0, 0.0, a * a * 0.65);
        return;
    }

    vec3 N = normalize(vNrm);
    vec3 V = normalize(uCam - vWorld);
    vec3 L = normalize(uSun);
    float ndl = max(dot(N, L), 0.0);
    float hemi = 0.5 + 0.5 * N.y;
    vec3 amb = mix(vec3(0.22, 0.20, 0.18), vec3(0.50, 0.58, 0.72), hemi);
    vec3 sunCol = vec3(1.0, 0.95, 0.84);
    vec3 base = uColor.rgb;
    float alpha = uColor.a;
    vec3 col;

    if (uMode == 1) {
        vec3 b = base;
        if (abs(N.y) < 0.5) {
            vec2 g = vec2(vWorld.x + vWorld.z, vWorld.y);
            vec2 cell = g / vec2(3.4, 3.8);
            vec2 f = fract(cell);
            float win = step(0.18, f.x) * step(f.x, 0.82) * step(0.22, f.y) * step(f.y, 0.78);
            float lit = step(0.72, hash21(floor(cell)));
            vec3 glass = mix(vec3(0.10, 0.15, 0.22), vec3(1.0, 0.88, 0.5), lit);
            b = mix(b, glass, win * step(3.0, vWorld.y));
        }
        col = b * (amb + ndl * sunCol * 0.85);
    } else if (uMode == 2) {
        col = base * (amb + ndl * sunCol * 0.85);
    } else {
        if (uUseTex == 1) {
            base *= texture(uTex, vUV).rgb;
        }
        if (uKind == 0) {
            base = mix(base, vec3(0.10, 0.09, 0.08), clamp(vDmg * 1.5, 0.0, 0.85));
        }
        vec3 diff = base * (amb + ndl * sunCol * 0.9);
        vec3 R = reflect(-V, N);
        vec3 env = skyColor(R);
        float ndv = max(dot(N, V), 0.0);
        float fres = pow(1.0 - ndv, 4.0);
        float refl = clamp(uMetal * 0.55 + fres * 0.55, 0.0, 0.95);
        if (uKind == 0) refl = clamp(refl + 0.22, 0.0, 0.9);
        if (uKind == 2) refl = clamp(0.35 + fres * 0.6, 0.0, 0.95);
        vec3 envTint = mix(vec3(1.0), base, uMetal);
        col = mix(diff, env * envTint, refl);
        float spec = pow(max(dot(R, L), 0.0), mix(24.0, 260.0, 1.0 - uRough));
        col += sunCol * spec * (0.25 + 0.55 * (1.0 - uRough));
        if (uKind == 3) {
            col = base * (0.55 + uEmit);
        }
    }
    col = mix(col, fogCol, fog);
    fragColor = vec4(col, alpha);
}
"""

    val GROUND_VS = """
#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uVP;
uniform vec2 uCenter;
uniform float uSize;
out vec3 vWorld;
void main() {
    vec3 w = vec3(uCenter.x + aPos.x * uSize, 0.0, uCenter.y + aPos.z * uSize);
    vWorld = w;
    gl_Position = uVP * vec4(w, 1.0);
}
"""

    val GROUND_FS = """
#version 300 es
precision highp float;
in vec3 vWorld;
uniform vec3 uCam;
uniform vec3 uSun;
uniform float uCity;
out vec4 fragColor;
""" + SKY_FN + """
void main() {
    vec2 p = vWorld.xz;
    float B = 150.0;
    float W = 16.0;
    vec2 m = mod(p, vec2(B));
    bool roadX = m.x < W;
    bool roadZ = m.y < W;
    float n = hash21(floor(p * 0.7));
    vec3 col;
    if (roadX || roadZ) {
        col = vec3(0.16, 0.16, 0.17) + n * 0.025;
        if (roadX && !roadZ) {
            if (abs(m.x - W * 0.5) < 0.15) col = mix(col, vec3(0.95, 0.78, 0.2), step(0.5, fract(p.y / 14.0)));
            if (m.x < 0.35 || m.x > W - 0.35) col = vec3(0.78);
        }
        if (roadZ && !roadX) {
            if (abs(m.y - W * 0.5) < 0.15) col = mix(col, vec3(0.95, 0.78, 0.2), step(0.5, fract(p.x / 14.0)));
            if (m.y < 0.35 || m.y > W - 0.35) col = vec3(0.78);
        }
    } else if (uCity > 0.5 && (m.x < W + 2.5 || m.y < W + 2.5 || m.x > B - 2.5 || m.y > B - 2.5)) {
        col = vec3(0.55, 0.55, 0.52) + n * 0.03;
    } else {
        col = mix(vec3(0.34, 0.48, 0.20), vec3(0.20, 0.42, 0.18), uCity) + n * 0.06;
    }
    float ndl = max(normalize(uSun).y, 0.0);
    col *= 0.60 + 0.5 * ndl;
    float dist = length(uCam - vWorld);
    float fog = clamp((dist - 220.0) / 520.0, 0.0, 1.0);
    col = mix(col, vec3(0.74, 0.84, 0.95), fog);
    fragColor = vec4(col, 1.0);
}
"""

    val SKY_VS = """
#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uVP;
uniform vec3 uCam;
out vec3 vDir;
void main() {
    vDir = aPos;
    gl_Position = uVP * vec4(aPos * 600.0 + uCam, 1.0);
}
"""

    val SKY_FS = """
#version 300 es
precision highp float;
in vec3 vDir;
uniform vec3 uSun;
out vec4 fragColor;
""" + SKY_FN + """
void main() {
    vec3 d = normalize(vDir);
    vec3 c = skyColor(d);
    float s = max(dot(d, normalize(uSun)), 0.0);
    c += vec3(1.0, 0.9, 0.7) * pow(s, 600.0) * 3.0;
    c += vec3(1.0, 0.75, 0.45) * pow(s, 10.0) * 0.18;
    fragColor = vec4(c, 1.0);
}
"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src.trimStart())
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            throw RuntimeException("shader: " + log)
        }
        return s
    }

    fun build(vs: String, fs: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs)
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(p)
            throw RuntimeException("link: " + log)
        }
        return p
    }
}
