package com.mission.openworld

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class Npc {
    var x = 0f
    var z = 0f
    var heading = 0f
    var cruise = 15f
    var speed = 15f
    var paint = 0
}

class GameRenderer(private val context: Context) : GLSurfaceView.Renderer {

    companion object {
        const val RAD2DEG = 57.29578f
        const val PI_F = 3.1415927f
        const val COL_R = 1.1f
        const val VIEW_BLOCKS = 4
        const val NPC_COUNT = 12

        // 0 = Porsche, 1 = Lexus
        val MAXV = floatArrayOf(88f, 56f)
        val ACCEL = floatArrayOf(16f, 9f)
        val WBASE = floatArrayOf(2.7f, 2.87f)

        val PAINTS = arrayOf(
            floatArrayOf(0.96f, 0.45f, 0.05f),  // laranja
            floatArrayOf(0.85f, 0.05f, 0.07f),  // vermelho
            floatArrayOf(0.10f, 0.30f, 0.95f),  // azul
            floatArrayOf(0.95f, 0.95f, 0.95f),  // branco
            floatArrayOf(0.03f, 0.03f, 0.04f),  // preto
            floatArrayOf(0.10f, 0.70f, 0.25f),  // verde
            floatArrayOf(0.60f, 0.15f, 0.85f),  // roxo
            floatArrayOf(0.75f, 0.77f, 0.80f),  // prata
            floatArrayOf(1.00f, 0.82f, 0.05f)   // amarelo
        )
        val SUN = floatArrayOf(0.40f, 0.80f, 0.35f)
    }

    // programas
    private var mainProg = 0
    private var groundProg = 0
    private var skyProg = 0

    // uniforms principal
    private var mVP = 0
    private var mModel = 0
    private var mCam = 0
    private var mSun = 0
    private var mColor = 0
    private var mMetal = 0
    private var mRough = 0
    private var mMode = 0
    private var mKind = 0
    private var mUseTex = 0
    private var mEmit = 0
    private var mTex = 0
    private var mDmg = 0
    private var mDeform = 0
    // chao
    private var gVP = 0
    private var gCenter = 0
    private var gSize = 0
    private var gCam = 0
    private var gSun = 0
    private var gCity = 0
    // ceu
    private var sVP = 0
    private var sCam = 0
    private var sSun = 0

    private var cube: Mesh? = null
    private var cone: Mesh? = null
    private var quad: Mesh? = null
    private var sphere: Mesh? = null
    private val cars = arrayOfNulls<CarModel>(2)
    private var traffic: CarModel? = null
    private var curCar = 0

    private var width = 1
    private var height = 1

    // estado do carro
    private var px = 8f
    private var pz = 40f
    private var heading = 0f
    private var vx = 0f
    private var vz = 0f
    private var steer = 0f
    private var steerAngle = 0f
    private var spin = 0f
    private var pitch = 0f
    private var roll = 0f
    private var prevVf = 0f
    private var longAcc = 0f
    private var braking = false

    // dano (frente, tras, esquerda, direita)
    private var dmgF = 0f
    private var dmgR = 0f
    private var dmgL = 0f
    private var dmgRt = 0f
    private var hitCooldown = 0f

    private var camHeading = 0f
    private var camMode = 0
    private var paintIdx = 0

    private var lastTime = 0L

    private val rnd = java.util.Random(12345L)
    private val npcs = Array(NPC_COUNT) { Npc() }

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val tmp = FloatArray(16)
    private val bodyM = FloatArray(16)
    private val npcM = FloatArray(16)
    private val wheelM = Array(4) { FloatArray(16) }

    private var eyeX = 0f
    private var eyeY = 0f
    private var eyeZ = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.74f, 0.84f, 0.95f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)

        mainProg = Shaders.build(Shaders.MAIN_VS, Shaders.MAIN_FS)
        groundProg = Shaders.build(Shaders.GROUND_VS, Shaders.GROUND_FS)
        skyProg = Shaders.build(Shaders.SKY_VS, Shaders.SKY_FS)

        mVP = GLES30.glGetUniformLocation(mainProg, "uVP")
        mModel = GLES30.glGetUniformLocation(mainProg, "uModel")
        mCam = GLES30.glGetUniformLocation(mainProg, "uCam")
        mSun = GLES30.glGetUniformLocation(mainProg, "uSun")
        mColor = GLES30.glGetUniformLocation(mainProg, "uColor")
        mMetal = GLES30.glGetUniformLocation(mainProg, "uMetal")
        mRough = GLES30.glGetUniformLocation(mainProg, "uRough")
        mMode = GLES30.glGetUniformLocation(mainProg, "uMode")
        mKind = GLES30.glGetUniformLocation(mainProg, "uKind")
        mUseTex = GLES30.glGetUniformLocation(mainProg, "uUseTex")
        mEmit = GLES30.glGetUniformLocation(mainProg, "uEmit")
        mTex = GLES30.glGetUniformLocation(mainProg, "uTex")
        mDmg = GLES30.glGetUniformLocation(mainProg, "uDmg")
        mDeform = GLES30.glGetUniformLocation(mainProg, "uDeform")

        gVP = GLES30.glGetUniformLocation(groundProg, "uVP")
        gCenter = GLES30.glGetUniformLocation(groundProg, "uCenter")
        gSize = GLES30.glGetUniformLocation(groundProg, "uSize")
        gCam = GLES30.glGetUniformLocation(groundProg, "uCam")
        gSun = GLES30.glGetUniformLocation(groundProg, "uSun")
        gCity = GLES30.glGetUniformLocation(groundProg, "uCity")

        sVP = GLES30.glGetUniformLocation(skyProg, "uVP")
        sCam = GLES30.glGetUniformLocation(skyProg, "uCam")
        sSun = GLES30.glGetUniformLocation(skyProg, "uSun")

        cube = Gfx.cube()
        cone = Gfx.cone()
        quad = Gfx.quad()
        sphere = Gfx.sphere()

        val porsche = CarModel(context, "car.bin", "tex/list.json")
        loadTextures(porsche)
        cars[0] = porsche
        cars[1] = CarModel(context, "lexus.bin", null)
        traffic = CarModel(context, "traffic.bin", null)

        for (n in npcs) respawn(n)
        lastTime = 0L
    }

    private fun loadTextures(c: CarModel) {
        val ids = IntArray(c.texNames.size)
        for (i in c.texNames.indices) {
            ids[i] = try {
                Gfx.loadTexture(context, "tex/" + c.texNames[i])
            } catch (e: Exception) {
                0
            }
        }
        c.texIds = ids
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = max(w, 1)
        height = max(h, 1)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = if (lastTime == 0L) 0.016f else (now - lastTime) / 1e9f
        lastTime = now
        if (dt > 0.05f) dt = 0.05f
        if (dt < 0.001f) dt = 0.001f
        update(dt)
        render()
    }

    // ------------------------------------------------------------------
    //  TRANSITO
    // ------------------------------------------------------------------
    private fun respawn(n: Npc) {
        val pci = floor(px / World.BLOCK).toInt()
        val pcj = floor(pz / World.BLOCK).toInt()
        n.cruise = 9f + rnd.nextFloat() * 12f
        n.speed = n.cruise
        n.paint = rnd.nextInt(PAINTS.size)
        for (t in 0 until 6) {
            val alongZ = rnd.nextBoolean()
            val dir = if (rnd.nextBoolean()) 1f else -1f
            val k = rnd.nextInt(3) - 1
            val off = (rnd.nextFloat() * 2f - 1f) * 330f
            if (alongZ) {
                n.x = (pci + k) * World.BLOCK + 8f - 3.5f * dir
                n.z = pz + off
                n.heading = if (dir > 0f) 0f else PI_F
            } else {
                n.z = (pcj + k) * World.BLOCK + 8f + 3.5f * dir
                n.x = px + off
                n.heading = dir * PI_F / 2f
            }
            val dx = n.x - px
            val dz = n.z - pz
            if (dx * dx + dz * dz > 140f * 140f) break
        }
    }

    private fun updateNpcs(dt: Float) {
        for (n in npcs) {
            n.speed += (n.cruise - n.speed) * min(1f, dt * 0.4f)
            n.x += sin(n.heading) * n.speed * dt
            n.z += cos(n.heading) * n.speed * dt
            val dx = n.x - px
            val dz = n.z - pz
            if (dx * dx + dz * dz > 420f * 420f) respawn(n)
        }
    }

    private fun addHit(hf: Float, hl: Float, impact: Float) {
        if (hitCooldown > 0f || impact < 3f) return
        hitCooldown = 0.35f
        val amt = ((impact - 2f) / 22f).coerceIn(0.05f, 1f)
        if (abs(hf) >= abs(hl)) {
            if (hf > 0f) dmgF = min(1f, dmgF + amt) else dmgR = min(1f, dmgR + amt)
        } else {
            if (hl > 0f) dmgL = min(1f, dmgL + amt) else dmgRt = min(1f, dmgRt + amt)
        }
    }

    private fun collideNpcs() {
        val fx = sin(heading)
        val fz = cos(heading)
        val lx = cos(heading)
        val lz = -sin(heading)
        val offs = floatArrayOf(-1.5f, 0f, 1.5f)
        for (n in npcs) {
            val dxq = n.x - px
            val dzq = n.z - pz
            if (dxq * dxq + dzq * dzq > 40f) continue
            val nfx = sin(n.heading)
            val nfz = cos(n.heading)
            for (a in offs) {
                for (b in offs) {
                    val ax = px + fx * a
                    val az = pz + fz * a
                    val bx = n.x + nfx * b
                    val bz = n.z + nfz * b
                    val dx = ax - bx
                    val dz = az - bz
                    val d2 = dx * dx + dz * dz
                    val rr = 2.1f
                    if (d2 < rr * rr) {
                        val d = sqrt(max(d2, 1e-6f))
                        val nx = dx / d
                        val nz = dz / d
                        val pen = rr - d
                        px += nx * pen * 0.6f
                        pz += nz * pen * 0.6f
                        n.x -= nx * pen * 0.4f
                        n.z -= nz * pen * 0.4f
                        val rvx = vx - n.speed * nfx
                        val rvz = vz - n.speed * nfz
                        val vn = rvx * nx + rvz * nz
                        if (vn < 0f) {
                            vx -= vn * nx * 1.2f
                            vz -= vn * nz * 1.2f
                            n.speed = max(n.speed * 0.5f, 0f)
                            addHit(-(nx * fx + nz * fz), -(nx * lx + nz * lz), -vn)
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    //  FISICA
    // ------------------------------------------------------------------
    private fun resetCar() {
        vx = 0f
        vz = 0f
        steer = 0f
        pitch = 0f
        roll = 0f
        longAcc = 0f
        prevVf = 0f
        val rx = ((px - 8f) / World.BLOCK).roundToInt()
        px = rx * World.BLOCK + 8f
        heading = 0f
        camHeading = 0f
    }

    private fun update(dt: Float) {
        World.setCity(GameInput.cityArrived)

        val want = GameInput.selectedCar.coerceIn(0, 1)
        if (want != curCar && cars[want] != null) {
            curCar = want
            resetCar()
        }
        if (GameInput.repairRequest) {
            GameInput.repairRequest = false
            dmgF = 0f
            dmgR = 0f
            dmgL = 0f
            dmgRt = 0f
        }
        if (GameInput.resetRequest) {
            GameInput.resetRequest = false
            resetCar()
        }
        if (GameInput.cameraRequest) {
            GameInput.cameraRequest = false
            camMode = (camMode + 1) % 3
        }
        if (GameInput.colorRequest) {
            GameInput.colorRequest = false
            paintIdx = (paintIdx + 1) % PAINTS.size
        }

        hitCooldown = max(0f, hitCooldown - dt)
        val total = ((dmgF + dmgR + dmgL + dmgRt) / 2.5f).coerceIn(0f, 1f)
        val broken = total >= 1f
        GameInput.damagePct = (total * 100f).toInt()
        val baseMax = MAXV[curCar]
        val maxV = baseMax * (1f - 0.55f * total)
        val accelBase = ACCEL[curCar]
        val wb = WBASE[curCar]

        val gas = GameInput.gas && !broken
        val brake = GameInput.brake
        val hand = GameInput.handbrake
        braking = brake || hand

        // direcao
        val target = (if (GameInput.steerLeft) 1f else 0f) - (if (GameInput.steerRight) 1f else 0f)
        val rate = if (target == 0f) 9f else 5f
        steer += (target - steer) * min(1f, rate * dt)

        var fx = sin(heading)
        var fz = cos(heading)
        var vf = vx * fx + vz * fz
        val speedAbs = abs(vf)
        val k40 = speedAbs / 40f
        val steerScale = 1f / (1f + k40 * k40)
        steerAngle = steer * steerScale * 0.62f
        var yawRate = vf / wb * tan(steerAngle)
        val maxLat = if (hand) 34f else 24f
        val maxYaw = maxLat / max(speedAbs, 3f)
        yawRate = yawRate.coerceIn(-maxYaw, maxYaw)
        if (hand && speedAbs > 8f) yawRate *= 1.35f
        heading += yawRate * dt

        fx = sin(heading)
        fz = cos(heading)
        val lx = cos(heading)
        val lz = -sin(heading)
        vf = vx * fx + vz * fz
        var vl = vx * lx + vz * lz

        var acc = 0f
        if (gas) {
            if (vf < -0.5f) {
                acc += 30f
            } else {
                val k = (vf / maxV).coerceIn(0f, 1f)
                acc += accelBase * (1f - k * k) + 3f
            }
        }
        if (brake) {
            if (vf > 0.5f) acc -= 34f else if (vf > -14f) acc -= 9f
        }
        acc -= 0.0009f * vf * abs(vf) * (88f / baseMax)
        if (!gas && !brake) {
            if (abs(vf) < 0.5f) {
                vf = 0f
            } else {
                acc -= if (vf > 0f) 2.2f else -2.2f
            }
        }
        vf += acc * dt
        vf = vf.coerceIn(-14f, maxV * 1.02f)

        val grip = if (hand) 1.3f else 7.5f
        vl *= exp(-grip * dt)
        if (hand) vf *= (1f - 0.6f * dt)

        vx = fx * vf + lx * vl
        vz = fz * vf + lz * vl
        px += vx * dt
        pz += vz * dt

        collide()
        updateNpcs(dt)
        collideNpcs()

        val vfNow = vx * fx + vz * fz
        val spd = sqrt(vx * vx + vz * vz)
        GameInput.speedKmh = (spd * 3.6f).toInt()

        longAcc += (((vfNow - prevVf) / dt) - longAcc) * min(1f, 8f * dt)
        prevVf = vfNow
        val pitchT = (-longAcc * 0.09f).coerceIn(-3.5f, 3.5f)
        pitch += (pitchT - pitch) * min(1f, 6f * dt)
        val latAcc = vfNow * yawRate
        val rollT = (latAcc * 0.1f).coerceIn(-4f, 4f)
        roll += (rollT - roll) * min(1f, 6f * dt)

        val r0 = cars[curCar]?.wheelRadius?.get(0) ?: 0.35f
        spin += vfNow / max(r0, 0.1f) * dt
        spin %= 6.2831855f

        // som do motor (marchas)
        val s = abs(vfNow)
        val sc = baseMax / 88f
        val limits = floatArrayOf(0f, 20f * sc, 38f * sc, 56f * sc, 74f * sc, 100f * sc)
        var g = 0
        while (g < 4 && s >= limits[g + 1]) g++
        val rpm = ((s - limits[g]) / (limits[g + 1] - limits[g])).coerceIn(0f, 1f)
        GameInput.enginePitch = 0.75f + rpm * 1.5f + (if (gas) 0.25f else 0f)
        GameInput.engineVol = if (broken) 0.1f else if (gas) 0.6f else 0.3f

        // camera
        var d = heading - camHeading
        while (d > PI_F) d -= 2f * PI_F
        while (d < -PI_F) d += 2f * PI_F
        camHeading += d * min(1f, dt * 3.2f)
    }

    private fun collide() {
        val ci = floor(px / World.BLOCK).toInt()
        val cj = floor(pz / World.BLOCK).toInt()
        val fxh = sin(heading)
        val fzh = cos(heading)
        val lxh = cos(heading)
        val lzh = -sin(heading)
        val offsets = floatArrayOf(-1.5f, 0f, 1.5f)
        for (o in offsets) {
            var cx = px + fxh * o
            var cz = pz + fzh * o
            for (i in (ci - 1)..(ci + 1)) {
                for (j in (cj - 1)..(cj + 1)) {
                    val blk = World.block(i, j)
                    for (b in blk.buildings) {
                        val qx = cx.coerceIn(b.minX, b.maxX)
                        val qz = cz.coerceIn(b.minZ, b.maxZ)
                        val dx = cx - qx
                        val dz = cz - qz
                        val d2 = dx * dx + dz * dz
                        if (d2 < COL_R * COL_R) {
                            var nx: Float
                            var nz: Float
                            var pen: Float
                            if (d2 > 1e-6f) {
                                val d = sqrt(d2)
                                nx = dx / d
                                nz = dz / d
                                pen = COL_R - d
                            } else {
                                val dl = cx - b.minX
                                val dr = b.maxX - cx
                                val dd = cz - b.minZ
                                val du = b.maxZ - cz
                                val m = min(min(dl, dr), min(dd, du))
                                if (m == dl) {
                                    nx = -1f; nz = 0f
                                } else if (m == dr) {
                                    nx = 1f; nz = 0f
                                } else if (m == dd) {
                                    nx = 0f; nz = -1f
                                } else {
                                    nx = 0f; nz = 1f
                                }
                                pen = m + COL_R
                            }
                            px += nx * pen
                            pz += nz * pen
                            cx += nx * pen
                            cz += nz * pen
                            val vn = vx * nx + vz * nz
                            if (vn < 0f) {
                                addHit(-(nx * fxh + nz * fzh), -(nx * lxh + nz * lzh), -vn)
                                vx -= vn * nx * 1.3f
                                vz -= vn * nz * 1.3f
                                vx *= 0.9f
                                vz *= 0.9f
                            }
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    //  DESENHO
    // ------------------------------------------------------------------
    private fun render() {
        val c = cars[curCar] ?: return
        val tm = traffic ?: return
        val cb = cube ?: return
        val cn = cone ?: return
        val qd = quad ?: return
        val sp = sphere ?: return

        GLES30.glViewport(0, 0, width, height)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // camera
        val dists = floatArrayOf(8.5f, 5.8f, 22f)
        val heights = floatArrayOf(2.8f, 1.7f, 15f)
        val dist = dists[camMode]
        val hgt = heights[camMode]
        val sh = sin(camHeading)
        val ch = cos(camHeading)
        eyeX = px - sh * dist
        eyeY = hgt
        eyeZ = pz - ch * dist
        val look = if (camMode == 2) 0f else 4f
        val tx = px + sin(heading) * look
        val tz = pz + cos(heading) * look
        val ty = 0.9f

        val speedFactor = (GameInput.speedKmh / 320f).coerceIn(0f, 1f)
        val fov = 60f + speedFactor * 16f
        Matrix.perspectiveM(proj, 0, fov, width.toFloat() / height.toFloat(), 0.3f, 1500f)
        Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ, tx, ty, tz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        // ceu
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(skyProg)
        GLES30.glUniformMatrix4fv(sVP, 1, false, vp, 0)
        GLES30.glUniform3f(sCam, eyeX, eyeY, eyeZ)
        GLES30.glUniform3f(sSun, SUN[0], SUN[1], SUN[2])
        Gfx.draw(sp)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)

        // chao
        GLES30.glUseProgram(groundProg)
        GLES30.glUniformMatrix4fv(gVP, 1, false, vp, 0)
        GLES30.glUniform2f(gCenter, eyeX, eyeZ)
        GLES30.glUniform1f(gSize, 900f)
        GLES30.glUniform3f(gCam, eyeX, eyeY, eyeZ)
        GLES30.glUniform3f(gSun, SUN[0], SUN[1], SUN[2])
        GLES30.glUniform1f(gCity, if (World.city) 1f else 0f)
        Gfx.draw(qd)

        // programa principal
        GLES30.glUseProgram(mainProg)
        GLES30.glUniformMatrix4fv(mVP, 1, false, vp, 0)
        GLES30.glUniform3f(mCam, eyeX, eyeY, eyeZ)
        GLES30.glUniform3f(mSun, SUN[0], SUN[1], SUN[2])
        GLES30.glUniform1i(mTex, 0)
        GLES30.glUniform4f(mDmg, 0f, 0f, 0f, 0f)
        GLES30.glUniform1f(mDeform, 0f)

        drawWorld(cb, cn)

        buildCarMatrices(c)
        GLES30.glUniform4f(mDmg, dmgF, dmgR, dmgL, dmgRt)
        drawModel(c, true, bodyM, wheelM, PAINTS[paintIdx], true, braking)
        GLES30.glUniform4f(mDmg, 0f, 0f, 0f, 0f)
        for (n in npcs) {
            npcMatrix(n)
            drawModel(tm, true, npcM, null, PAINTS[n.paint], false, false)
        }

        // transparentes
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)

        // sombras
        GLES30.glUniform1f(mDeform, 0f)
        GLES30.glUniform1i(mMode, 3)
        GLES30.glUniform4f(mColor, 0f, 0f, 0f, 1f)
        Matrix.setIdentityM(tmp, 0)
        Matrix.translateM(tmp, 0, px, 0.04f, pz)
        Matrix.rotateM(tmp, 0, heading * RAD2DEG, 0f, 1f, 0f)
        Matrix.scaleM(tmp, 0, c.width * 0.62f, 1f, c.length * 0.58f)
        GLES30.glUniformMatrix4fv(mModel, 1, false, tmp, 0)
        Gfx.draw(qd)
        for (n in npcs) {
            Matrix.setIdentityM(tmp, 0)
            Matrix.translateM(tmp, 0, n.x, 0.04f, n.z)
            Matrix.rotateM(tmp, 0, n.heading * RAD2DEG, 0f, 1f, 0f)
            Matrix.scaleM(tmp, 0, 1.2f, 1f, 2.8f)
            GLES30.glUniformMatrix4fv(mModel, 1, false, tmp, 0)
            Gfx.draw(qd)
        }

        GLES30.glUniform4f(mDmg, dmgF, dmgR, dmgL, dmgRt)
        drawModel(c, false, bodyM, wheelM, PAINTS[paintIdx], true, braking)
        GLES30.glUniform4f(mDmg, 0f, 0f, 0f, 0f)
        for (n in npcs) {
            npcMatrix(n)
            drawModel(tm, false, npcM, null, PAINTS[n.paint], false, false)
        }

        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun npcMatrix(n: Npc) {
        Matrix.setIdentityM(npcM, 0)
        Matrix.translateM(npcM, 0, n.x, 0f, n.z)
        Matrix.rotateM(npcM, 0, n.heading * RAD2DEG, 0f, 1f, 0f)
    }

    private fun setPlain(mode: Int, r: Float, g: Float, b: Float) {
        GLES30.glUniform1i(mMode, mode)
        GLES30.glUniform4f(mColor, r, g, b, 1f)
        GLES30.glUniform1f(mMetal, 0f)
        GLES30.glUniform1f(mRough, 1f)
        GLES30.glUniform1i(mKind, 1)
        GLES30.glUniform1i(mUseTex, 0)
        GLES30.glUniform1f(mEmit, 0f)
        GLES30.glUniform1f(mDeform, 0f)
    }

    private fun drawWorld(cb: Mesh, cn: Mesh) {
        val ci = floor(eyeX / World.BLOCK).toInt()
        val cj = floor(eyeZ / World.BLOCK).toInt()
        for (i in (ci - VIEW_BLOCKS)..(ci + VIEW_BLOCKS)) {
            for (j in (cj - VIEW_BLOCKS)..(cj + VIEW_BLOCKS)) {
                val bcx = (i + 0.5f) * World.BLOCK
                val bcz = (j + 0.5f) * World.BLOCK
                val ddx = bcx - eyeX
                val ddz = bcz - eyeZ
                if (ddx * ddx + ddz * ddz > 640f * 640f) continue
                val blk = World.block(i, j)

                for (b in blk.buildings) {
                    val w = b.maxX - b.minX
                    val d = b.maxZ - b.minZ
                    Matrix.setIdentityM(tmp, 0)
                    Matrix.translateM(tmp, 0, (b.minX + b.maxX) * 0.5f, 0f, (b.minZ + b.maxZ) * 0.5f)
                    Matrix.scaleM(tmp, 0, w, b.h, d)
                    GLES30.glUniformMatrix4fv(mModel, 1, false, tmp, 0)
                    setPlain(1, b.r, b.g, b.b)
                    Gfx.draw(cb)
                }

                for (t in blk.trees) {
                    Matrix.setIdentityM(tmp, 0)
                    Matrix.translateM(tmp, 0, t.x, 0f, t.z)
                    Matrix.scaleM(tmp, 0, 0.6f, 3.5f * t.s, 0.6f)
                    GLES30.glUniformMatrix4fv(mModel, 1, false, tmp, 0)
                    setPlain(2, 0.35f, 0.22f, 0.12f)
                    Gfx.draw(cb)

                    Matrix.setIdentityM(tmp, 0)
                    Matrix.translateM(tmp, 0, t.x, 3f * t.s, t.z)
                    Matrix.scaleM(tmp, 0, 3.2f * t.s, 7f * t.s, 3.2f * t.s)
                    GLES30.glUniformMatrix4fv(mModel, 1, false, tmp, 0)
                    setPlain(2, 0.12f, 0.38f, 0.14f)
                    Gfx.draw(cn)
                }
            }
        }
    }

    private fun buildCarMatrices(c: CarModel) {
        Matrix.setIdentityM(bodyM, 0)
        Matrix.translateM(bodyM, 0, px, 0f, pz)
        Matrix.rotateM(bodyM, 0, heading * RAD2DEG, 0f, 1f, 0f)
        Matrix.translateM(bodyM, 0, 0f, 0.5f, 0f)
        Matrix.rotateM(bodyM, 0, roll, 0f, 0f, 1f)
        Matrix.rotateM(bodyM, 0, pitch, 1f, 0f, 0f)
        Matrix.translateM(bodyM, 0, 0f, -0.5f, 0f)

        for (i in 0 until 4) {
            System.arraycopy(bodyM, 0, wheelM[i], 0, 16)
            val wc = c.wheelCenter[i]
            Matrix.translateM(wheelM[i], 0, wc[0], wc[1], wc[2])
            if (i < 2) {
                Matrix.rotateM(wheelM[i], 0, steerAngle * RAD2DEG, 0f, 1f, 0f)
            }
            Matrix.rotateM(wheelM[i], 0, spin * RAD2DEG, 1f, 0f, 0f)
        }
    }

    private fun drawModel(
        c: CarModel, opaque: Boolean, body: FloatArray, wheels: Array<FloatArray>?,
        paint: FloatArray, deform: Boolean, lights: Boolean
    ) {
        GLES30.glUniform1i(mMode, 0)
        for (p in c.parts) {
            val isGlass = p.kind == 2
            if (isGlass == opaque) continue
            val m = if (p.group == 0 || wheels == null) body else wheels[p.group - 1]
            GLES30.glUniformMatrix4fv(mModel, 1, false, m, 0)
            GLES30.glUniform1f(mDeform, if (deform && p.group == 0) 1f else 0f)
            var r = p.r
            var g = p.g
            var b = p.b
            if (p.kind == 0 && p.group == 0) {
                r = paint[0]; g = paint[1]; b = paint[2]
            }
            GLES30.glUniform4f(mColor, r, g, b, p.a)
            GLES30.glUniform1f(mMetal, p.metal)
            GLES30.glUniform1f(mRough, p.rough)
            GLES30.glUniform1i(mKind, p.kind)
            var emit = 0f
            if (p.kind == 3) {
                emit = if (p.r > 0.9f && p.g < 0.3f) (if (lights) 1.2f else 0.3f) else 0.8f
            }
            GLES30.glUniform1f(mEmit, emit)
            if (p.tex >= 0 && p.tex < c.texIds.size && c.texIds[p.tex] != 0) {
                GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
                GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, c.texIds[p.tex])
                GLES30.glUniform1i(mUseTex, 1)
            } else {
                GLES30.glUniform1i(mUseTex, 0)
            }
            Gfx.draw(p.mesh)
        }
    }
}
