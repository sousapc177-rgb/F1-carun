package com.mission.openworld

import android.content.Context
import org.json.JSONArray
import java.nio.ByteBuffer
import java.nio.ByteOrder

class CarPart(
    val group: Int,   // 0 = corpo, 1 = RF, 2 = LF, 3 = RR, 4 = LR
    val kind: Int,    // 0 = pintura, 1 = normal, 2 = vidro, 3 = luz
    val tex: Int,
    val r: Float,
    val g: Float,
    val b: Float,
    val a: Float,
    val metal: Float,
    val rough: Float,
    val mesh: Mesh
)

class CarModel(context: Context, binName: String, texList: String?) {
    val wheelCenter = Array(4) { FloatArray(3) }
    val wheelRadius = FloatArray(4)
    val wheelWidth = FloatArray(4)
    var length = 4.5f
    var width = 2.0f
    var height = 1.2f
    val parts = ArrayList<CarPart>()
    val texNames = ArrayList<String>()
    var texIds = IntArray(0)

    init {
        val bytes = context.assets.open(binName).readBytes()
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        bb.position(4) // "CAR1"
        val partCount = bb.int
        bb.int // quantidade de texturas
        for (w in 0 until 4) {
            wheelCenter[w][0] = bb.float
            wheelCenter[w][1] = bb.float
            wheelCenter[w][2] = bb.float
            wheelRadius[w] = bb.float
            wheelWidth[w] = bb.float
        }
        length = bb.float
        width = bb.float
        height = bb.float

        for (p in 0 until partCount) {
            val group = bb.get().toInt() and 0xFF
            val kind = bb.get().toInt() and 0xFF
            val tex = bb.short.toInt()
            val r = bb.float
            val g = bb.float
            val b = bb.float
            val a = bb.float
            val metal = bb.float
            val rough = bb.float
            val nv = bb.int
            val ni = bb.int

            val vb = ByteBuffer.allocateDirect(nv * 32).order(ByteOrder.nativeOrder()).asFloatBuffer()
            val vSrc = bb.asFloatBuffer()
            vSrc.limit(nv * 8)
            vb.put(vSrc)
            vb.position(0)
            bb.position(bb.position() + nv * 32)

            val ib = ByteBuffer.allocateDirect(ni * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
            val iSrc = bb.asIntBuffer()
            iSrc.limit(ni)
            ib.put(iSrc)
            ib.position(0)
            bb.position(bb.position() + ni * 4)

            val mesh = Gfx.upload(vb, nv * 8, ib, ni)
            parts.add(CarPart(group, kind, tex, r, g, b, a, metal, rough, mesh))
        }

        if (texList != null) {
            try {
                val txt = context.assets.open(texList).bufferedReader().use { it.readText() }
                val arr = JSONArray(txt)
                for (k in 0 until arr.length()) texNames.add(arr.getString(k))
            } catch (e: Exception) {
                // sem texturas, segue o jogo
            }
        }
    }
}
