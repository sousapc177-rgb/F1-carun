package com.mission.openworld

object GameInput {
    @Volatile var steerLeft = false
    @Volatile var steerRight = false
    @Volatile var gas = false
    @Volatile var brake = false
    @Volatile var handbrake = false

    @Volatile var cameraRequest = false
    @Volatile var colorRequest = false
    @Volatile var resetRequest = false
    @Volatile var repairRequest = false

    @Volatile var selectedCar = 0
    @Volatile var cityArrived = false

    @Volatile var speedKmh = 0
    @Volatile var damagePct = 0
    @Volatile var enginePitch = 0.8f
    @Volatile var engineVol = 0.3f

    fun releaseAll() {
        steerLeft = false
        steerRight = false
        gas = false
        brake = false
        handbrake = false
    }
}
