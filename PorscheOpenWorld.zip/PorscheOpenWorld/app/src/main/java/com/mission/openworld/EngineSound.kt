package com.mission.openworld

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

class EngineSound {
    private var track: AudioTrack? = null
    private val sampleRate = 22050

    fun start() {
        if (track != null) return
        try {
            val frames = 4410 // 0.2 s -> 11 ciclos de 55 Hz
            val data = ShortArray(frames)
            val base = 55.0
            for (i in 0 until frames) {
                val t = i.toDouble() / sampleRate
                var s = 0.0
                for (h in 1..9) {
                    s += sin(2.0 * PI * base * h * t + h * 0.6) / h
                }
                data[i] = (s * 6500.0).toInt().coerceIn(-32000, 32000).toShort()
            }
            @Suppress("DEPRECATION")
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, sampleRate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                frames * 2, AudioTrack.MODE_STATIC
            )
            t.write(data, 0, frames)
            t.setLoopPoints(0, frames, -1)
            t.setVolume(0.3f)
            t.play()
            track = t
        } catch (e: Exception) {
            track = null
        }
    }

    fun update(pitch: Float, vol: Float) {
        try {
            val t = track ?: return
            val rate = (sampleRate * pitch).toInt().coerceIn(4000, 80000)
            t.setPlaybackRate(rate)
            t.setVolume(vol)
        } catch (e: Exception) {
            // ignora
        }
    }

    fun stop() {
        try {
            track?.stop()
            track?.release()
        } catch (e: Exception) {
            // ignora
        }
        track = null
    }
}
