package com.mission.openworld

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val TRIP_HOURS = 72
        const val LEXUS_PRICE = 75000L
        const val REPAIR_PRICE = 3000L
        const val MONEY_PER_SEC = 100.0
        const val REQ_MUSIC = 77
    }

    private lateinit var glView: GameView
    private lateinit var speedText: TextView
    private lateinit var moneyText: TextView
    private lateinit var tripText: TextView
    private lateinit var dmgText: TextView

    private lateinit var garagePanel: LinearLayout
    private lateinit var shopInfo: TextView
    private lateinit var shopMsg: TextView
    private lateinit var btnPorsche: TextView
    private lateinit var btnLexus: TextView
    private lateinit var btnRepair: TextView

    private lateinit var radioPanel: LinearLayout
    private lateinit var radioText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var sound: EngineSound? = null

    private var money = 0.0
    private var ownLexus = false
    private var tripSec = 0.0
    private var lastTick = 0L
    private var saveCounter = 0
    private val nf: NumberFormat = NumberFormat.getIntegerInstance(Locale("pt", "BR"))

    private var player: MediaPlayer? = null
    private val playlist = ArrayList<Uri>()
    private val playlistNames = ArrayList<String>()
    private var trackIdx = 0
    private var musicWasPlaying = false

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = if (lastTick == 0L) 0.0 else (now - lastTick) / 1e9
            lastTick = now

            money += MONEY_PER_SEC * dt
            tripSec += dt
            if (!GameInput.cityArrived && tripSec >= TRIP_HOURS * 60.0) {
                GameInput.cityArrived = true
                Toast.makeText(this@MainActivity, "Passaram 72 horas... você chegou na cidade!", Toast.LENGTH_LONG).show()
                save()
            }

            speedText.text = GameInput.speedKmh.toString() + " km/h"
            updateHud()
            if (garagePanel.visibility == View.VISIBLE) updateShop()
            sound?.update(GameInput.enginePitch, GameInput.engineVol)

            saveCounter++
            if (saveCounter >= 100) {
                saveCounter = 0
                save()
            }
            handler.postDelayed(this, 50)
        }
    }

    // ------------------------------------------------------------------
    //  utilidades de tela
    // ------------------------------------------------------------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, gravity: Int, l: Int, t: Int, r: Int, b: Int): FrameLayout.LayoutParams {
        val p = FrameLayout.LayoutParams(dp(w), dp(h), gravity)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun styled(label: String, textSize: Float): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.textSize = textSize
        tv.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.setColor(Color.argb(120, 15, 15, 25))
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(2), Color.argb(170, 255, 255, 255))
        tv.background = bg
        return tv
    }

    private fun makeButton(label: String, textSize: Float, onChange: (Boolean) -> Unit): TextView {
        val tv = styled(label, textSize)
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f
                    onChange(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    onChange(false)
                }
            }
            true
        }
        return tv
    }

    private fun makeTap(label: String, textSize: Float, onTap: () -> Unit): TextView {
        val tv = styled(label, textSize)
        tv.setOnClickListener { onTap() }
        return tv
    }

    private fun hudText(size: Float, color: Int): TextView {
        val tv = TextView(this)
        tv.textSize = size
        tv.setTextColor(color)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setShadowLayer(6f, 0f, 2f, Color.BLACK)
        return tv
    }

    private fun panelBackground(): GradientDrawable {
        val bg = GradientDrawable()
        bg.setColor(Color.argb(240, 14, 14, 24))
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(2), Color.argb(200, 255, 255, 255))
        return bg
    }

    @Suppress("DEPRECATION")
    private fun goImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    // ------------------------------------------------------------------
    //  salvar / carregar
    // ------------------------------------------------------------------
    private fun load() {
        val sp = getSharedPreferences("save", MODE_PRIVATE)
        money = sp.getLong("money", 0L).toDouble()
        ownLexus = sp.getBoolean("lexus", false)
        tripSec = sp.getLong("trip", 0L).toDouble()
        GameInput.selectedCar = if (ownLexus) sp.getInt("car", 0) else 0
        GameInput.cityArrived = tripSec >= TRIP_HOURS * 60.0
    }

    private fun save() {
        getSharedPreferences("save", MODE_PRIVATE).edit()
            .putLong("money", money.toLong())
            .putBoolean("lexus", ownLexus)
            .putLong("trip", tripSec.toLong())
            .putInt("car", GameInput.selectedCar)
            .apply()
    }

    // ------------------------------------------------------------------
    //  HUD e garagem
    // ------------------------------------------------------------------
    private fun updateHud() {
        moneyText.text = "R$ " + nf.format(money.toLong())
        if (GameInput.cityArrived) {
            tripText.text = "Você chegou na cidade!"
        } else {
            val hoursLeft = TRIP_HOURS - tripSec / 60.0
            val hh = hoursLeft.toInt()
            val mm = ((hoursLeft - hh) * 60.0).toInt()
            tripText.text = "Cidade em " + hh + "h " + mm + "min"
        }
        val dmg = GameInput.damagePct
        if (dmg >= 100) {
            dmgText.text = "CARRO QUEBRADO! Conserte na garagem"
            dmgText.setTextColor(Color.RED)
        } else {
            dmgText.text = "Dano: " + dmg + "%"
            dmgText.setTextColor(if (dmg >= 50) Color.rgb(255, 170, 0) else Color.WHITE)
        }
    }

    private fun updateShop() {
        btnPorsche.text = if (GameInput.selectedCar == 0) "EM USO" else "USAR"
        btnLexus.text = if (!ownLexus) "COMPRAR  R$ " + nf.format(LEXUS_PRICE)
        else if (GameInput.selectedCar == 1) "EM USO" else "USAR"
        btnLexus.alpha = if (!ownLexus && money < LEXUS_PRICE) 0.6f else 1f
        btnRepair.text = "CONSERTAR  R$ " + nf.format(REPAIR_PRICE)
        shopInfo.text = "Seu dinheiro: R$ " + nf.format(money.toLong()) + "   |   Dano: " + GameInput.damagePct + "%"
    }

    private fun selectCar(id: Int) {
        if (id == 1 && !ownLexus) return
        GameInput.selectedCar = id
        save()
        updateShop()
    }

    private fun buyLexus() {
        if (ownLexus) return
        if (money >= LEXUS_PRICE) {
            money -= LEXUS_PRICE
            ownLexus = true
            GameInput.selectedCar = 1
            shopMsg.text = "Parabéns! Você comprou o Lexus ES 300h!"
            save()
        } else {
            val falta = LEXUS_PRICE - money.toLong()
            shopMsg.text = "Faltam R$ " + nf.format(falta) + " pra comprar"
        }
        updateShop()
    }

    private fun repair() {
        if (GameInput.damagePct <= 0) {
            shopMsg.text = "Seu carro não tá quebrado"
            return
        }
        if (money >= REPAIR_PRICE) {
            money -= REPAIR_PRICE
            GameInput.repairRequest = true
            shopMsg.text = "Carro consertado!"
            save()
        } else {
            val falta = REPAIR_PRICE - money.toLong()
            shopMsg.text = "Faltam R$ " + nf.format(falta) + " pro conserto"
        }
        updateShop()
    }

    private fun buildGaragePanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(18), dp(14), dp(18), dp(14))
        panel.background = panelBackground()
        panel.isClickable = true

        val title = hudText(20f, Color.WHITE)
        title.text = "GARAGEM"
        panel.addView(title)

        shopInfo = TextView(this)
        shopInfo.setTextColor(Color.rgb(255, 215, 90))
        shopInfo.textSize = 14f
        panel.addView(shopInfo)

        // Porsche
        val rowP = LinearLayout(this)
        rowP.orientation = LinearLayout.HORIZONTAL
        rowP.gravity = Gravity.CENTER_VERTICAL
        val nameP = TextView(this)
        nameP.text = "Porsche Mission X"
        nameP.setTextColor(Color.WHITE)
        nameP.textSize = 16f
        btnPorsche = makeTap("USAR", 13f) { selectCar(0) }
        rowP.addView(nameP, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        rowP.addView(btnPorsche, LinearLayout.LayoutParams(dp(180), dp(44)))
        val lpP = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpP.topMargin = dp(10)
        panel.addView(rowP, lpP)

        // Lexus
        val rowL = LinearLayout(this)
        rowL.orientation = LinearLayout.HORIZONTAL
        rowL.gravity = Gravity.CENTER_VERTICAL
        val nameL = TextView(this)
        nameL.text = "Lexus ES 300h"
        nameL.setTextColor(Color.WHITE)
        nameL.textSize = 16f
        btnLexus = makeTap("COMPRAR", 13f) { buyLexus() }
        rowL.addView(nameL, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        rowL.addView(btnLexus, LinearLayout.LayoutParams(dp(180), dp(44)))
        val lpL = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpL.topMargin = dp(10)
        panel.addView(rowL, lpL)

        // Conserto
        val rowR = LinearLayout(this)
        rowR.orientation = LinearLayout.HORIZONTAL
        rowR.gravity = Gravity.CENTER_VERTICAL
        val nameR = TextView(this)
        nameR.text = "Oficina"
        nameR.setTextColor(Color.WHITE)
        nameR.textSize = 16f
        btnRepair = makeTap("CONSERTAR", 13f) { repair() }
        rowR.addView(nameR, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        rowR.addView(btnRepair, LinearLayout.LayoutParams(dp(180), dp(44)))
        val lpR = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpR.topMargin = dp(10)
        panel.addView(rowR, lpR)

        shopMsg = TextView(this)
        shopMsg.setTextColor(Color.rgb(140, 255, 160))
        shopMsg.textSize = 14f
        val lpM = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpM.topMargin = dp(10)
        panel.addView(shopMsg, lpM)

        val close = makeTap("FECHAR", 14f) { garagePanel.visibility = View.GONE }
        val lpC = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        lpC.topMargin = dp(10)
        panel.addView(close, lpC)

        return panel
    }

    // ------------------------------------------------------------------
    //  radio
    // ------------------------------------------------------------------
    private fun nameOf(uri: Uri): String {
        var n = "música"
        try {
            val c = contentResolver.query(uri, null, null, null, null)
            if (c != null) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) n = c.getString(idx)
                c.close()
            }
        } catch (e: Exception) {
            // ignora
        }
        return n
    }

    private fun pickMusic() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, REQ_MUSIC)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MUSIC && resultCode == RESULT_OK && data != null) {
            playlist.clear()
            playlistNames.clear()
            val clip = data.clipData
            if (clip != null) {
                for (k in 0 until clip.itemCount) {
                    val u = clip.getItemAt(k).uri
                    playlist.add(u)
                    playlistNames.add(nameOf(u))
                }
            } else {
                val u = data.data
                if (u != null) {
                    playlist.add(u)
                    playlistNames.add(nameOf(u))
                }
            }
            trackIdx = 0
            playTrack()
        }
    }

    private fun playTrack() {
        if (playlist.isEmpty()) return
        try {
            player?.release()
            val mp = MediaPlayer()
            mp.setDataSource(this, playlist[trackIdx])
            mp.setOnCompletionListener { stepTrack(1) }
            mp.prepare()
            mp.start()
            player = mp
            radioText.text = "♪ " + playlistNames[trackIdx]
        } catch (e: Exception) {
            radioText.text = "Não consegui tocar esse arquivo"
        }
    }

    private fun stepTrack(step: Int) {
        if (playlist.isEmpty()) return
        trackIdx = (trackIdx + step + playlist.size) % playlist.size
        playTrack()
    }

    private fun togglePlay() {
        val p = player ?: return
        try {
            if (p.isPlaying) p.pause() else p.start()
        } catch (e: Exception) {
            // ignora
        }
    }

    private fun buildRadioPanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(12), dp(10), dp(12), dp(10))
        panel.background = panelBackground()
        panel.isClickable = true

        radioText = TextView(this)
        radioText.text = "Nenhuma música"
        radioText.setTextColor(Color.WHITE)
        radioText.textSize = 12f
        radioText.maxLines = 1
        radioText.ellipsize = TextUtils.TruncateAt.END
        panel.addView(radioText, LinearLayout.LayoutParams(dp(250), LinearLayout.LayoutParams.WRAP_CONTENT))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val b1 = makeTap("MÚSICAS", 11f) { pickMusic() }
        val b2 = makeTap("<<", 14f) { stepTrack(-1) }
        val b3 = makeTap("||", 14f) { togglePlay() }
        val b4 = makeTap(">>", 14f) { stepTrack(1) }
        val l1 = LinearLayout.LayoutParams(dp(84), dp(38))
        val l2 = LinearLayout.LayoutParams(dp(50), dp(38))
        l2.leftMargin = dp(6)
        val l3 = LinearLayout.LayoutParams(dp(50), dp(38))
        l3.leftMargin = dp(6)
        val l4 = LinearLayout.LayoutParams(dp(50), dp(38))
        l4.leftMargin = dp(6)
        row.addView(b1, l1)
        row.addView(b2, l2)
        row.addView(b3, l3)
        row.addView(b4, l4)
        val lpRow = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpRow.topMargin = dp(8)
        panel.addView(row, lpRow)
        return panel
    }

    // ------------------------------------------------------------------
    //  ciclo de vida
    // ------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        load()

        val root = FrameLayout(this)
        glView = GameView(this)
        root.addView(glView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // velocimetro
        speedText = hudText(30f, Color.WHITE)
        speedText.text = "0 km/h"
        speedText.gravity = Gravity.CENTER
        root.addView(speedText, lp(200, 50, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 8, 0, 0))

        // dinheiro, viagem e dano (canto esquerdo de cima)
        moneyText = hudText(22f, Color.rgb(255, 215, 90))
        root.addView(moneyText, lp(260, 34, Gravity.TOP or Gravity.START, 12, 6, 0, 0))
        tripText = hudText(13f, Color.WHITE)
        root.addView(tripText, lp(260, 20, Gravity.TOP or Gravity.START, 12, 42, 0, 0))
        dmgText = hudText(13f, Color.WHITE)
        root.addView(dmgText, lp(300, 20, Gravity.TOP or Gravity.START, 12, 62, 0, 0))

        // direcao (esquerda embaixo)
        root.addView(makeButton("<", 34f) { GameInput.steerLeft = it },
            lp(95, 95, Gravity.BOTTOM or Gravity.START, 24, 0, 0, 24))
        root.addView(makeButton(">", 34f) { GameInput.steerRight = it },
            lp(95, 95, Gravity.BOTTOM or Gravity.START, 130, 0, 0, 24))

        // pedais (direita embaixo)
        root.addView(makeButton("ACELERAR", 15f) { GameInput.gas = it },
            lp(120, 130, Gravity.BOTTOM or Gravity.END, 0, 0, 24, 24))
        root.addView(makeButton("FREIO / RÉ", 13f) { GameInput.brake = it },
            lp(100, 95, Gravity.BOTTOM or Gravity.END, 0, 0, 156, 24))
        root.addView(makeButton("DRIFT", 14f) { GameInput.handbrake = it },
            lp(100, 52, Gravity.BOTTOM or Gravity.END, 0, 0, 156, 130))

        // botoes de cima (direita)
        root.addView(makeButton("CÂMERA", 12f) { if (it) GameInput.cameraRequest = true },
            lp(80, 42, Gravity.TOP or Gravity.END, 0, 10, 10, 0))
        root.addView(makeButton("COR", 12f) { if (it) GameInput.colorRequest = true },
            lp(64, 42, Gravity.TOP or Gravity.END, 0, 10, 98, 0))
        root.addView(makeButton("VOLTAR", 12f) { if (it) GameInput.resetRequest = true },
            lp(80, 42, Gravity.TOP or Gravity.END, 0, 10, 170, 0))
        root.addView(makeTap("GARAGEM", 12f) {
            updateShop()
            garagePanel.visibility = if (garagePanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }, lp(92, 42, Gravity.TOP or Gravity.END, 0, 10, 258, 0))

        // radio (cantinho esquerdo)
        radioPanel = buildRadioPanel()
        radioPanel.visibility = View.GONE
        root.addView(makeTap("RÁDIO", 12f) {
            radioPanel.visibility = if (radioPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }, lp(80, 38, Gravity.TOP or Gravity.START, 12, 88, 0, 0))
        val rp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START)
        rp.setMargins(dp(12), dp(132), 0, 0)
        root.addView(radioPanel, rp)

        // garagem
        garagePanel = buildGaragePanel()
        garagePanel.visibility = View.GONE
        root.addView(garagePanel, FrameLayout.LayoutParams(dp(440), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        setContentView(root)
        goImmersive()
        updateHud()
        updateShop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        val s = EngineSound()
        s.start()
        sound = s
        lastTick = 0L
        handler.post(ticker)
        if (musicWasPlaying) {
            try {
                player?.start()
            } catch (e: Exception) {
                // ignora
            }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        sound?.stop()
        sound = null
        GameInput.releaseAll()
        glView.onPause()
        musicWasPlaying = try {
            player?.isPlaying == true
        } catch (e: Exception) {
            false
        }
        try {
            player?.pause()
        } catch (e: Exception) {
            // ignora
        }
        save()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            player?.release()
        } catch (e: Exception) {
            // ignora
        }
        player = null
    }
}
